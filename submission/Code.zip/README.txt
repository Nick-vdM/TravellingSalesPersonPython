* Requires wxPython

* Run with `python ./interface.py`

* Must be connected to cisco database

* Requires 'favicon.png' and 'gear.png' in the same file for images to 
function properly. I'd embed these in the program to make it moveable, but...
py files are preferred